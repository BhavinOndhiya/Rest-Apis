const getAllProducts = async(req,res)=>{
    res.status(200).json({msg:"I am Getting All Products"});
};

const getAllProductsTesting = async(req,res)=>{
    res.status(200).json({msg:"I am Getting All Products Testing"});
};

module.exports = {getAllProducts,getAllProductsTesting};