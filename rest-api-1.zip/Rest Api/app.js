const express = require('express');
const app = express();
app.use(express.json());

// Mock data for companies
let companies = [
  { id: 1, name: 'GraphBuds', location: 'Ahemdabad' },
  { id: 2, name: 'Google LLC', location: 'Mountain View, California' },
  { id: 3, name: 'Microsoft Corporation', location: 'Redmond, Washington' }
];

// Endpoint to check if service is running
app.get('/status', (req, res) => {
  res.status(200).json({ message: 'Service is running.' });
});

// Endpoint to get company details by ID
app.get('/company/:id', (req, res) => {
  const companyId = parseInt(req.params.id);
  const company = companies.find(c => c.id === companyId);
  if (company) {
    res.status(200).json(company);
  } else {
    res.status(404).json({ message: `Company with ID ${companyId} not found.` });
  }
});

// Endpoint to compare company details by ID and return delta
app.get('/company/:id1/compare/:id2', (req, res) => {
  const companyId1 = parseInt(req.params.id1);
  const companyId2 = parseInt(req.params.id2);
  const company1 = companies.find(c => c.id === companyId1);
  const company2 = companies.find(c => c.id === companyId2);
  if (company1 && company2) {
    const delta = {};
    Object.keys(company1).forEach(key => {
      if (company1[key] !== company2[key]) {
        delta[key] = { before: company1[key], after: company2[key] };
      }
    });
    res.status(200).json(delta);
  } else {
    res.status(404).json({ message: 'Company not found.' });
  }
});

// Endpoint to insert a new company record
app.post('/company', (req, res) => {
  const newCompany = req.body;
  const companyId = companies.length + 1;
  newCompany.id = companyId;
  companies.push(newCompany);
  res.status(201).json(newCompany);
});

// Endpoint to update existing company details by ID
app.put('/company/:id', (req, res) => {
  const companyId = parseInt(req.params.id);
  const updateCompany = req.body;
  const index = companies.findIndex(c => c.id === companyId);
  if (index !== -1) {
    companies[index] = { id: companyId, ...updateCompany };
    res.status(200).json(companies[index]);
  } else {
    res.status(404).json({ message: `Company with ID ${companyId} not found.` });
  }
});

// Endpoint to return a list of all companies
app.get('/companies', (req, res) => {
  res.status(200).json(companies);
});

// Start the server
const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}.`);
});
